# task-tracker-ls

Task tracker using localstorage

## Running the project
`npm start`
